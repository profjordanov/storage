function sumFirstLast(arr) {
	//TODO
}
sumFirstLast(['20', '30', '40']);
sumFirstLast(['5', '10']);