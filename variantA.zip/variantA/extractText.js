function extractText() {
	// TODO with jQuery
}