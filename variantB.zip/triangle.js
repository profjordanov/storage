function triangleArea(arr) {
	//TODO
}

triangleArea(['3', '4', '5']);
triangleArea(['30', '40', '50']);