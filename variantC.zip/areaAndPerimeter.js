function areaAndPerimeter([width, height]) {
	
}