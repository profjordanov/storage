import logo from '../assets/investment-calculator-logo.png';

export default function Header() {
  return (
    // add header tag
    // add img with the logo
    // add h1 - Investment Calculator
    <>
    </>
  );
}
