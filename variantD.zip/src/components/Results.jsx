import { calculateInvestmentResults, formatter } from '../util/investment.js';

export default function Results({ input }) {
  const resultsData = calculateInvestmentResults(input);
  const initialInvestment = 0;

  return (
    <table id="result">
      <thead>
        ...
      </thead>
      <tbody>
        {resultsData.map((yearData) => {
          const totalInterest =
            yearData.valueEndOfYear -
            yearData.annualInvestment * yearData.year -
            initialInvestment;
          // calculate totalAmountInvested equals valueEndOfYear minus total interest;

          return (
            <tr key={yearData.year}>
              <td>{yearData.year}</td>
              <td>{formatter.format(yearData.valueEndOfYear)}</td>
              <td>todo: format interest</td>
              <td>todo: format totalInterest</td>
              <td>todo: format totalAmountInvested</td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );
}
