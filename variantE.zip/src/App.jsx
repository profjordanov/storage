import { useState } from "react";

const initialFriends = [
  {
    id: 118836,
    name: "Clark",
    image: "https://i.pravatar.cc/48?u=118836",
    balance: -7,
  },
  {
    id: 933372,
    name: "Sarah",
    image: "https://i.pravatar.cc/48?u=933372",
    balance: 20,
  },
  {
    id: 499476,
    name: "Anthony",
    image: "https://i.pravatar.cc/48?u=499476",
    balance: 0,
  },
];

function Button({ children, onClick }) {
  return (
    <button className="button" onClick={onClick}>
      {children}
    </button>
  );
}

export default function App() {
  const [friends, setFriends] = useState(initialFriends);
  const [showAddFriend, setShowAddFriend] = useState(false);
  const [selectedFriend, setSelectedFriend] = useState(null);

  function handleShowAddFriend() {
  }

  function handleAddFriend(friend) {

  }

  function handleSelection(friend) {

  }

  function handleSplitBill(value) {

  }

  return (
    <div className="app">
      <div className="sidebar">
        <FriendsList

        />


        <Button onClick={handleShowAddFriend}>
          {showAddFriend ? "Close" : "Add friend"}
        </Button>
      </div>


    </div>
  );
}

function FriendsList({ friends, onSelection, selectedFriend }) {
  return (
    <ul>
      
    </ul>
  );
}

function Friend({ friend, onSelection, selectedFriend }) {
  const isSelected = selectedFriend?.id === friend.id;

  return (
    <li className={isSelected ? "selected" : ""}>

    </li>
  );
}

function FormAddFriend({ onAddFriend }) {
  
  return (
    <form className="form-add-friend" onSubmit="">
      <label>👫 Friend name</label>
      <input
      />

      <label>🌄 Image URL</label>
      <input
      />

      <Button>Add</Button>
    </form>
  );
}

function FormSplitBill({ selectedFriend, onSplitBill }) {

  return (
    <form className="form-split-bill" >

      <label>💰 Bill value</label>
      <input

      />

      <label>🧍‍♀️ Your expense</label>
      <input

      />

      <label>🤑 Who is paying the bill</label>
      <select

      >
        <option value="user">You</option>
        <option value="friend">{selectedFriend.name}</option>
      </select>

      <Button>Split bill</Button>
    </form>
  );
}